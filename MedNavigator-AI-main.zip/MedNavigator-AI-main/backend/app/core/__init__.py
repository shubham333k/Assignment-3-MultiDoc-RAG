# Core AI pipeline package
